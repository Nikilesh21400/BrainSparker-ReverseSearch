package com.reversesearch.brainsparker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class MyRewards extends AppCompatActivity {

    private ProgressBar progressBar;
    private LinearLayout Rewards_LinearLayout;
    private SharedPreferences sharedPreferences;
    private JSONArray jsonArray;
    private JSONObject jsonObject;
    private int TotalRewards,ResourceId;
    private  TextView NoRewards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_rewards);

        progressBar=findViewById(R.id.MyRewards_ProgressBar);
        Rewards_LinearLayout=findViewById(R.id.MyRewards_Linear_Layout);
        NoRewards=findViewById(R.id.MyRewards_NoRewardsTextView);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        try {
            GetMyCoupons();
        }catch (Exception e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }

    }



    private void GetMyCoupons(){

        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/ShowRewardstoUserfromDB.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(MyCourses.this, "" + response, Toast.LENGTH_SHORT).show();


                try{
                    jsonArray=new JSONArray(response);
                    progressBar.setVisibility(View.INVISIBLE);

                    TotalRewards=jsonArray.length();

                    if(TotalRewards==0){
                        NoRewards.setVisibility(View.VISIBLE);
                    }else{
                        for (int i = 0; i < TotalRewards; i++) {
                            jsonObject = jsonArray.getJSONObject(i);

                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                            View Reward = getLayoutInflater().inflate(R.layout.myrewards_rewards_button, null);

                            TextView RewardNumber = Reward.findViewById(R.id.MyRewards_Button_LanguageNumber);
                            TextView RewardName = Reward.findViewById(R.id.MyRewards_Button_LanguageName);
                            TextView Status = Reward.findViewById(R.id.MyRewards_Button_LanguageStatus);
                            ImageView RewardImage = Reward.findViewById(R.id.MyRewards_Button_LanguageImage);
                            TextView Platform = Reward.findViewById(R.id.MyRewards_Button_PlatformName);
                            Button Link = Reward.findViewById(R.id.MyRewards_Button_CourseLinkButton);
                            final String Website = jsonObject.getString("Link");

                            ResourceId = getResources().getIdentifier("@drawable/" + (jsonObject.getString("CourseName").toLowerCase().replaceAll(Pattern.quote("+"), "p").replaceAll(" ", "")), null, getPackageName());
                            RewardImage.setImageDrawable(getResources().getDrawable(ResourceId));

                            RewardNumber.setText((i + 1) + " / " + TotalRewards);
                            RewardName.setText(jsonObject.getString("CourseName"));
                            if (jsonObject.getString("Status").trim().equals("Open")) {
                                Status.setTextColor(Color.parseColor("#3CD36E"));
                                Status.setText("Open");
                            } else {
                                Status.setTextColor(Color.parseColor("#A22C08"));
                                Status.setText("Expired");
                            }

                            Platform.setText(jsonObject.getString("Platform"));

                            Link.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Toast.makeText(MyRewards.this, ""+Website, Toast.LENGTH_SHORT).show();
                                    Uri uri = Uri.parse(Website); // missing 'http://' will cause crashed
                                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                    startActivity(intent);
                                }
                            });


                            if (i == 0) {
                                layoutParams.setMargins(0, 0, 0, 0);
                            } else {
                                layoutParams.setMargins(0, 10, 0, 0);
                            }

                            Reward.setLayoutParams(layoutParams);
                            Rewards_LinearLayout.addView(Reward);


                        }
                    }
                }catch (Exception e){
                    //Toast.makeText(MyCourses.this, ""+e, Toast.LENGTH_SHORT).show();
                }



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("MailID", sharedPreferences.getString("MailID",""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }



}