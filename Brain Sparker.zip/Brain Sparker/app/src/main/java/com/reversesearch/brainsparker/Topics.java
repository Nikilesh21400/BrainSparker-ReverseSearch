package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Topics extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    private SharedPreferences sharedPreferences;
    private TextView LanguageName;
    private LinearLayout Display_Topics;
    private JSONArray jsonArray;
    private JSONObject jsonObject;
    private String TopicStatus[];
    private ScrollView TopicsScrollView;
    private ProgressBar progressBar;
    private int ResourceId;
    private ImageView LanguageImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topics);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        LanguageName=findViewById(R.id.Topics_LanguageName);
        Display_Topics=findViewById(R.id.Topics_Show_Topics_LinearLayout);
        TopicsScrollView=findViewById(R.id.Topics_TopicsScrollView);
        progressBar=findViewById(R.id.Topics_ProgressBar);
        LanguageImageView=findViewById(R.id.Topics_LanguageImage);

        TopicsScrollView.setVisibility(View.INVISIBLE);

        ResourceId = getResources().getIdentifier("@drawable/"+(sharedPreferences.getString("language","").toLowerCase().replaceAll(Pattern.quote("+"),"p").replaceAll(" ","")), null, getPackageName());
        LanguageImageView.setImageDrawable(getResources().getDrawable(ResourceId));

        LanguageName.setText(sharedPreferences.getString("language",""));

        try {
            Display_Topics_from_DB();
        }catch (Exception e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }


        BottomNavigationView bottomNavigationView=findViewById(R.id.rnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.getMenu().setGroupCheckable(0,false,true);

    }


    private void Display_Topics_from_DB(){

        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/GetTopicsfromDB.php";
        //final SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    jsonArray = new JSONArray(response);
                    TopicStatus=new String[jsonArray.length()];
                    progressBar.setVisibility(View.INVISIBLE);
                    TopicsScrollView.setVisibility(View.VISIBLE);

                    for(int i=0;i<jsonArray.length();i++){
                        jsonObject=jsonArray.getJSONObject(i);
                        TopicStatus[i]=jsonObject.getString("status");
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                        View Topic_Display_Button_View = getLayoutInflater().inflate(R.layout.topics_display_button, null);
                        final Button Topic_Display_Button=Topic_Display_Button_View.findViewById(R.id.Home_Language_Display_Button);
                        Topic_Display_Button.setText(jsonObject.getString("topic"));
                        Topic_Display_Button.setId(i);
                        if(i==0){
                            layoutParams.setMargins(0,0,0,0);
                            //Topic_Display_Button.setBackgroundColor(Color.parseColor("#0A65A5"));
                        }else{
                            if(TopicStatus[i-1].equals("Completed")==false){
                                Drawable img = ContextCompat.getDrawable(Topics.this, R.drawable.custom_lock);
                                Topic_Display_Button.setCompoundDrawablesWithIntrinsicBounds(null, null, img, null);
                                Topic_Display_Button.setAlpha(0.5f);
                                //Topic_Display_Button.setBackgroundColor(Color.parseColor("#03DAC5"));
                            }
                            layoutParams.setMargins(0,10,0,0);
                        }
                        Topic_Display_Button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(Topic_Display_Button.getId()==0||TopicStatus[(Topic_Display_Button.getId())-1].equals("Completed"))
                                {
                                    if(Topic_Display_Button.getId()==jsonArray.length()-1){
                                        sharedPreferences.edit().putBoolean("LastTopic",true).apply();
                                    }else{
                                        sharedPreferences.edit().putBoolean("LastTopic",false).apply();
                                    }
                                    if(TopicStatus[(Topic_Display_Button.getId())].equals("Completed")){
                                        sharedPreferences.edit().putString("TopicCompletionStatus","Completed").apply();
                                    }else{
                                        sharedPreferences.edit().putString("TopicCompletionStatus","Not Completed").apply();
                                    }
                                    //Toast.makeText(Topics.this, "" + Topic_Display_Button.getText(), Toast.LENGTH_SHORT).show();
                                    sharedPreferences.edit().putString("topic",Topic_Display_Button.getText().toString().trim()).apply();
                                    startActivity(new Intent(Topics.this,TopicResourceExam.class));
                                }else{
                                    Toast.makeText(Topics.this, "Complete Previous Topics", Toast.LENGTH_SHORT).show();
                                }
                                //Toast.makeText(Topics.this, ""+Topic_Display_Button.getText(), Toast.LENGTH_SHORT).show();
                            }
                        });
                        Topic_Display_Button_View.setLayoutParams(layoutParams);
                        Display_Topics.addView(Topic_Display_Button_View);
                    }

                }catch (Exception e){
                    Toast.makeText(Topics.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("MailID",sharedPreferences.getString("MailID",""));
                params.put("language",sharedPreferences.getString("language",""));
                return params;
            }};
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.Home:
                startActivity(new Intent(this,Home.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                break;
            case R.id.Sparkers:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,Sparkers.class));
                break;
            case R.id.Account:
                startActivity(new Intent(this, Account.class));
                break;
        }
        return true;
    }



}