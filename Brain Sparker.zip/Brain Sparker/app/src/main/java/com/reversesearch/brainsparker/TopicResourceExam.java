package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.regex.Pattern;

public class TopicResourceExam extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    private ImageView LanguageImage;
    private TextView LanguageName,TopicName;
    private LinearLayout ResourcesLayout,ExamLayout;
    private SharedPreferences sharedPreferences;
    private int ResourceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_resource_exam);


        LanguageImage=findViewById(R.id.TopicResourceExam_LanguageImage);
        LanguageName=findViewById(R.id.TopicResourceExam_LanguageName);
        TopicName=findViewById(R.id.TopicResourceExam_TopicName);
        ResourcesLayout=findViewById(R.id.TopicResourceExam_ResourcesLayout);
        ExamLayout=findViewById(R.id.TopicResourceExam_ExamLayout);
        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        ResourceId = getResources().getIdentifier("@drawable/"+(sharedPreferences.getString("language","").toLowerCase().replaceAll(Pattern.quote("+"),"p").replaceAll(" ","")), null, getPackageName());
        LanguageImage.setImageDrawable(getResources().getDrawable(ResourceId));

        LanguageName.setText(sharedPreferences.getString("language",""));
        TopicName.setText(sharedPreferences.getString("topic",""));


        ResourcesLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TopicResourceExam.this,Resources.class));
            }
        });


        ExamLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TopicResourceExam.this,Quiz.class));
            }
        });

        BottomNavigationView bottomNavigationView=findViewById(R.id.rnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.getMenu().setGroupCheckable(0,false,true);


    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.Home:
                startActivity(new Intent(this,Home.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            case R.id.Sparkers:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,Sparkers.class));
                break;
            case R.id.Account:
                startActivity(new Intent(this, Account.class));
                break;
        }
        return true;
    }




}