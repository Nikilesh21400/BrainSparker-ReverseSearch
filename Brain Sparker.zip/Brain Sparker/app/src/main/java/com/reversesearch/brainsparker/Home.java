package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Home extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    private SharedPreferences sharedPreferences;
    private LinearLayout Display_Languages;
    private JSONArray jsonArray;
    private JSONObject jsonObject;
    private ProgressBar progressBar;
    private ScrollView LanguageScrollView;
    private String[] LanguagesList;
    private int TotalLanguageDisplayLinearLayouts=0,TotalLanguagesCount,ResourceId;
    private TextView WelcomeText;
    private View Language_Display_Button_View;// Row Language Layout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Display_Languages=findViewById(R.id.Home_Show_Languages_LinearLayout);
        progressBar=findViewById(R.id.Home_ProgressBar);
        LanguageScrollView=findViewById(R.id.Home_Language_ScrollView);
        WelcomeText=findViewById(R.id.Home_User_WelcomeText);
        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        WelcomeText.setText("Welcome "+sharedPreferences.getString("Name","").split(" ")[0]);

        LanguageScrollView.setVisibility(View.INVISIBLE);

        try {
            Display_Languages_from_DB();
        }catch (Exception e){
            //Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }

        BottomNavigationView bottomNavigationView=findViewById(R.id.rnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.getMenu().setGroupCheckable(0,false,true);

    }

    private void Display_Languages_from_DB(){

        //Toast.makeText(this, "Method Called", Toast.LENGTH_SHORT).show();
        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/GetLanguagesfromDB.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    jsonArray = new JSONArray(response);
                    progressBar.setVisibility(View.INVISIBLE);
                    LanguageScrollView.setVisibility(View.VISIBLE);
                    TotalLanguagesCount=jsonArray.length();
                    //Toast.makeText(Home.this, ""+response, Toast.LENGTH_SHORT).show();
                    LanguagesList=new String[TotalLanguagesCount];
                    for(int i=0;i<jsonArray.length();i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        LanguagesList[i] = jsonObject.getString("language");

                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

                        //Language_Display_Button_View = getLayoutInflater().inflate(R.layout.home_language_display_button, null);
                        if (i % 2 == 0) {
                            Language_Display_Button_View = getLayoutInflater().inflate(R.layout.home_language_display_button, null);
                            final LinearLayout Language_Display_LinearLayout = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout1);
                            Language_Display_LinearLayout.setVisibility(View.VISIBLE);
                            ImageView Language_Display_Image = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout1_ImageView);
                            ResourceId = getResources().getIdentifier("@drawable/"+(LanguagesList[i].toLowerCase().replaceAll(Pattern.quote("+"),"p").replaceAll(" ","")), null, getPackageName());
                            Language_Display_Image.setImageDrawable(getResources().getDrawable(ResourceId));
                            TextView Language_Display_TextView = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout1_TextView);
                            Language_Display_TextView.setText(jsonObject.getString("language"));
                            Language_Display_LinearLayout.setId(i);
                            Language_Display_LinearLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Toast.makeText(Home.this, ""+Language_Display_Button.getText(), Toast.LENGTH_SHORT).show();
                                    sharedPreferences.edit().putString("language", LanguagesList[Language_Display_LinearLayout.getId()]).apply();
                                    startActivity(new Intent(Home.this, Topics.class));
                                }
                            });
                        } else {
                            final LinearLayout Language_Display_LinearLayout = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout2);
                            Language_Display_LinearLayout.setVisibility(View.VISIBLE);
                            ImageView Language_Display_Image = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout2_ImageView);
                            ResourceId = getResources().getIdentifier("@drawable/"+(LanguagesList[i].toLowerCase().replaceAll(Pattern.quote("+"),"p").replaceAll(" ","")), null, getPackageName());
                            Language_Display_Image.setImageDrawable(getResources().getDrawable(ResourceId));
                            TextView Language_Display_TextView = Language_Display_Button_View.findViewById(R.id.Home_Language_Display_Layout2_TextView);
                            Language_Display_TextView.setText(jsonObject.getString("language"));
                            //LanguagesList[i] = jsonObject.getString("language");
                            Language_Display_LinearLayout.setId(i);
                            Language_Display_LinearLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Toast.makeText(Home.this, ""+Language_Display_Button.getText(), Toast.LENGTH_SHORT).show();
                                    sharedPreferences.edit().putString("language", LanguagesList[Language_Display_LinearLayout.getId()]).apply();
                                    startActivity(new Intent(Home.this, Topics.class));
                                }
                            });
                        }
                        if (i == TotalLanguagesCount - 1 || i % 2 != 0) {
                            //TotalLanguagesCount++;
                            if(TotalLanguageDisplayLinearLayouts==1){
                                layoutParams.setMargins(0, 0, 0, 0);
                            } else {
                                layoutParams.setMargins(0, 10, 0, 0);
                            }
                            Language_Display_Button_View.setLayoutParams(layoutParams);
                            Display_Languages.addView(Language_Display_Button_View);
                        }

                    }

                }catch (Exception e){
                    Toast.makeText(Home.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                return params;
            }};
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.Home:
                //startActivity(new Intent(this,Home.class));
                break;
            case R.id.Sparkers:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,Sparkers.class));
                break;
            case R.id.Account:
                startActivity(new Intent(this, Account.class));
                break;
        }
        return true;
    }


}