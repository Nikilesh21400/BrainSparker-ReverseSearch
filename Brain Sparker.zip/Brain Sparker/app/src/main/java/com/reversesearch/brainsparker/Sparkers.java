package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Sparkers extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    private TextView Name,MyScore;
    private LinearLayout SparkersRanksLinearLayout;
    private ProgressBar progressBar;
    private SharedPreferences sharedPreferences;
    private JSONArray jsonArray;
    private JSONObject jsonObject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sparkers);


        Name=findViewById(R.id.Sparkers_NameTextView);
        MyScore=findViewById(R.id.Sparkers_RankTextView);
        SparkersRanksLinearLayout=findViewById(R.id.Sparkers_Ranks_Linear_Layout);
        progressBar=findViewById(R.id.Sparkers_ProgressBar);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        Name.setText(sharedPreferences.getString("Name",""));

        showSparkers();



        BottomNavigationView bottomNavigationView=findViewById(R.id.rnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.getMenu().setGroupCheckable(0,false,true);


    }

    private void showSparkers(){
        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/ShowSparkersListfromDB.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(Sparkers.this, "" + response, Toast.LENGTH_SHORT).show();

                try{
                    jsonArray=new JSONArray(response);
                    progressBar.setVisibility(View.INVISIBLE);
                    jsonObject=jsonArray.getJSONObject(0);
                    if(jsonObject.getString("MyScore").equals("You have no Score")) {
                        MyScore.setText(jsonObject.getString("MyScore"));
                    }else{
                        MyScore.setText("Your Score :  "+jsonObject.getString("MyScore"));
                    }

                    for(int i=1;i<jsonArray.length();i++) {
                        jsonObject=jsonArray.getJSONObject(i);

                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                        View Score_Row = getLayoutInflater().inflate(R.layout.sparkers_rank_buttun, null);

                        TextView Icon=Score_Row.findViewById(R.id.Sparkers_Rank_Button_Icon);
                        TextView Name=Score_Row.findViewById(R.id.Sparkers_Rank_Button_Name);
                        TextView Score=Score_Row.findViewById(R.id.Sparkers_Rank_Button_Score);

                        if(i==1) {
                            Icon.setBackgroundResource(R.drawable.gold);
                        }else if(i==2) {
                            Icon.setBackgroundResource(R.drawable.silver);
                        }else if(i==3) {
                            Icon.setBackgroundResource(R.drawable.bronze);
                        }else{
                            Icon.setText(i+"");
                        }
                        Name.setText(jsonObject.getString("Name").split(" ")[0]);
                        Score.setText(jsonObject.getString("Points"));

                        if(i==1){
                            layoutParams.setMargins(0, 0, 0, 0);
                        } else {
                            layoutParams.setMargins(0, 10, 0, 0);
                        }

                        Score_Row.setLayoutParams(layoutParams);
                        SparkersRanksLinearLayout.addView(Score_Row);


                    }
                }catch (Exception e){
                    Toast.makeText(Sparkers.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("MailID", sharedPreferences.getString("MailID",""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Sparkers.this,Home.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.Home:
                startActivity(new Intent(this,Home.class));
                break;
            case R.id.Sparkers:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                //startActivity(new Intent(this,Sparkers.class));
                break;
            case R.id.Account:
                startActivity(new Intent(this, Account.class));
                break;
        }
        return true;
    }


}