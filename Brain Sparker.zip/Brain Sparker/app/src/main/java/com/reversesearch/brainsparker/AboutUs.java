package com.reversesearch.brainsparker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class AboutUs extends AppCompatActivity {

    private TextView AboutUs_Content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        AboutUs_Content=findViewById(R.id.AboutUs_Content);

        AboutUs_Content.setText("Reverse search is a TEAM comprising students who are willing to make a difference in Learning practices and we teammates do believe that by creating stress free learning , every individual will try to learn and lead a successful life. Our first step towards creating a stress free and joyful environment for learning , we are presenting BRAIN SPARKER an E-Learning App.\n\n- Team Reverse Search -");

    }
}