package com.reversesearch.brainsparker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class Account extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{

    private TextView Name,MailID,MobileNumber;
    private Button Rewards,MyCourses,ChangePassword,Logout,AboutUs,ContactUs;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        Name=findViewById(R.id.Profile_NameTextView);
        MailID=findViewById(R.id.Profile_MailIDView);
        MobileNumber=findViewById(R.id.Profile_MobileNumberView);
        Rewards=findViewById(R.id.Profile_RewardsButton);
        MyCourses=findViewById(R.id.Profile_MyCoursesButton);
        ContactUs=findViewById(R.id.Profile_ContactUs);
        AboutUs=findViewById(R.id.Profile_AboutUs);
        ChangePassword=findViewById(R.id.Profile_ChangePasswordButton);
        Logout=findViewById(R.id.Profile_LogoutButton);

        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        Name.setText(sharedPreferences.getString("Name",""));
        MailID.setText(sharedPreferences.getString("MailID",""));
        MobileNumber.setText(sharedPreferences.getString("MobileNumber",""));


        BottomNavigationView bottomNavigationView=findViewById(R.id.rnavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.getMenu().setGroupCheckable(0,false,true);



        Rewards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Account.this,MyRewards.class));
            }
        });


        MyCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Account.this,MyCourses.class));
            }
        });



        AboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Account.this,AboutUs.class));
            }
        });



        ContactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    Intent intent = new Intent (Intent.ACTION_VIEW , Uri.parse("mailto:" + "brainsparker24@gmail.com"));
                    intent.putExtra(Intent.EXTRA_SUBJECT, "your_subject");
                    intent.putExtra(Intent.EXTRA_TEXT, "your_text");
                    startActivity(intent);
                }catch(ActivityNotFoundException e){

                }

            }
        });



        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeUserPasswordinDB();
            }
        });



        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences.edit().clear().commit();
                startActivity(new Intent(Account.this,Login.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });



    }


    private void ChangeUserPasswordinDB(){

        AlertDialog.Builder builder=new AlertDialog.Builder(Account.this);
        View ChangePasswordView=getLayoutInflater().inflate(R.layout.change_password_dialog,null);
        final TextView OldPassword=ChangePasswordView.findViewById(R.id.ChangePassword_OldPassword);
        final TextView NewPassword=ChangePasswordView.findViewById(R.id.ChangePassword_NewPassword);
        final TextView ConfirmNewPassword=ChangePasswordView.findViewById(R.id.ChangePassword_ConfirmNewPassword);
        final LinearLayout EmailParent=ChangePasswordView.findViewById(R.id.ChangePassword_MailID_Parent);
        final TextView ErrorTextView=ChangePasswordView.findViewById(R.id.ChangePassword_ErrorTextView);
        final Button ChangePassword=ChangePasswordView.findViewById(R.id.ChangePassword_SendMailButton);
        final ProgressBar ChangePassword_ProgressBar=ChangePasswordView.findViewById(R.id.ChangePassword_ProgressBar);
        ChangePassword_ProgressBar.setVisibility(View.INVISIBLE);
        ImageView Close=ChangePasswordView.findViewById(R.id.ChangePassword_CloseButton);
        final LinearLayout ChangePassword_MailSentStatusLinearLayout=ChangePasswordView.findViewById(R.id.ChangePassword_MailSentStatusLinearLayout);
        builder.setView(ChangePasswordView);
        final AlertDialog alertDialog=builder.create();
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ErrorTextView.setVisibility(View.INVISIBLE);

                if(ChangePassword.getText().toString().trim().equals("Change Password")){
                    if(OldPassword.getText().toString().trim().equals("")||NewPassword.getText().toString().trim().equals("")||ConfirmNewPassword.getText().toString().trim().equals("")){
                        if(OldPassword.getText().toString().trim().equals("")){
                            OldPassword.setError("Cannot be Empty");
                        }
                        if(NewPassword.getText().toString().trim().equals("")){
                            NewPassword.setError("Cannot be Empty");
                        }
                        if(NewPassword.getText().toString().trim().equals("")){
                            NewPassword.setError("Cannot be Empty");
                        }
                        if(ConfirmNewPassword.getText().toString().trim().equals("")){
                            ConfirmNewPassword.setError("Cannot be Empty");
                        }
                        ErrorTextView.setText("Password Cannot be Empty");
                        ErrorTextView.setVisibility(View.VISIBLE);
                    }else if(OldPassword.getText().toString().trim().length()<8||NewPassword.getText().toString().trim().length()<8||ConfirmNewPassword.getText().toString().trim().length()<8){
                        if(OldPassword.getText().toString().trim().length()<8){
                            OldPassword.setError("Must be atleast 8 Characters");
                        }
                        if(NewPassword.getText().toString().trim().length()<8){
                            NewPassword.setError("Must be atleast 8 Characters");
                        }
                        if(ConfirmNewPassword.getText().toString().trim().length()<8){
                            ConfirmNewPassword.setError("Must be atleast 8 Characters");
                        }
                        ErrorTextView.setText("Password must be atleast 8 Characters");
                        ErrorTextView.setVisibility(View.VISIBLE);
                    }else if (NewPassword.getText().toString().trim().equals(ConfirmNewPassword.getText().toString().trim())==false){
                        ConfirmNewPassword.setError("Paswords must Match");
                        ErrorTextView.setText("Paswords must Match");
                        ErrorTextView.setVisibility(View.VISIBLE);
                    }else if (NewPassword.getText().toString().trim().equals(OldPassword.getText().toString().trim())){
                        OldPassword.setError("Old and New Passwords must be different");
                        ErrorTextView.setText("Old and New Passwords must be different");
                        ErrorTextView.setVisibility(View.VISIBLE);}
                    else{
                        OldPassword.setEnabled(false);
                        NewPassword.setEnabled(false);
                        ConfirmNewPassword.setEnabled(false);
                        ChangePassword.setEnabled(false);
                        ChangePassword_ProgressBar.setVisibility(View.VISIBLE);
                        String url = BuildConfig.Base_URL+"ReverseSearchQuiz/ChangePassword.php";
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response.trim().equals("Password Changed Successfully")) {
                                    ChangePassword_ProgressBar.setVisibility(View.INVISIBLE);
                                    EmailParent.setVisibility(View.INVISIBLE);
                                    ChangePassword.setText("Ok");
                                    ChangePassword.setEnabled(true);
                                    ChangePassword_MailSentStatusLinearLayout.setVisibility(View.VISIBLE);
                                }else {
                                    ChangePassword_ProgressBar.setVisibility(View.INVISIBLE);
                                    OldPassword.setEnabled(true);
                                    NewPassword.setEnabled(true);
                                    ConfirmNewPassword.setEnabled(true);
                                    ChangePassword.setEnabled(true);
                                    if (response.trim().equals("Wrong Password Entered")) {
                                        ErrorTextView.setText("Wrong Password Entered");
                                        OldPassword.setError("Wrong Password Entered");
                                        ErrorTextView.setVisibility(View.VISIBLE);
                                    } else {
                                        ErrorTextView.setText("Error occurred please try again");
                                        ErrorTextView.setVisibility(View.VISIBLE);
                                    }
                                }


                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                ErrorTextView.setText("Error occurred please try again");
                                ErrorTextView.setVisibility(View.VISIBLE);
//                Toast.makeText(QuizActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                            }
                        }) {
                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<>();
                                params.put("MailID",sharedPreferences.getString("MailID",""));
                                params.put("OldPassword", OldPassword.getText().toString().trim());
                                params.put("NewPassword", NewPassword.getText().toString().trim());
                                return params;
                            }
                        };
                        RequestQueue requestQueue = Volley.newRequestQueue(Account.this);
                        requestQueue.add(stringRequest);
                    }


                }else {
                    alertDialog.dismiss();
                }
            }
        });

        Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });


    }




    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.Home:
                startActivity(new Intent(this,Home.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            case R.id.Sparkers:
                //Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,Sparkers.class));
                break;
            case R.id.Account:
                //startActivity(new Intent(this, Account.class));
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Account.this,Home.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
    }



}