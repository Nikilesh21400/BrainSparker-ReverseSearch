package com.reversesearch.brainsparker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

public class Resources extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private String Url;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resources);


        webView=findViewById(R.id.Resources_WebView);
        progressBar=findViewById(R.id.Resources_ProgressBar);
        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);


        Url=(sharedPreferences.getString("language","").trim().replace(" ","").toLowerCase())+"_"+(sharedPreferences.getString("topic","").trim().replace(" ","").toLowerCase())+".pdf";

        Url=BuildConfig.Base_URL+"ReverseSearchQuiz/ResourcesPdfs/"+Url;


        webView.setWebViewClient(new WebDisplayPDF());
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        WebSettings webSettings = webView.getSettings();
        //webSettings.setBuiltInZoomControls(true);
        webSettings.setSupportZoom(true);

        webSettings.setBuiltInZoomControls(true);
        webSettings.setSupportZoom(true);
        webView.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url="+Url);


    }


    private class WebDisplayPDF extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.INVISIBLE);
        }
    }



}